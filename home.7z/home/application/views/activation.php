<? $this->load->view("front_common/header") ?>

    <div class="content">
      <div class="container">
        <div class="col-lg-8 card-col verification">
         <img src="<? echo base_url('assets/images/pending.png') ?>" alt="">
          <h4>Verfication Pending !</h4>
          <p>we have sent an email to mailid to verify your email address and activate your account</p>
          <p><a href="<? echo base_url('') ?>">Click here</a> if you did not receive an email</p>
        </div>
      </div>
    </div>


<? $this->load->view("front_common/footer") ?>
