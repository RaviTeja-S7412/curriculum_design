<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {
	
	public function __construct(){
		
		parent::__construct();
		if(!$this->session->userdata('institute_id')){
        	redirect('/institute-login');
        }
		
	}

	public function getCourses(){
		
		$id = $this->input->post("id");
		$cid = $this->input->post("cid");
		
		$this->db->select("tbl_courses.*");
		$this->db->join("tbl_courses","tbl_program_course_links.course=tbl_courses.id");
		$data = $this->db->get_where("tbl_program_course_links",["tbl_program_course_links.program"=>$id])->result();
		
		$html = '<option value="">Select Course</option>';
		foreach($data as $d){
			$sel = ($cid == $d->id) ? 'selected' : '';	
			$html .= '<option value="'.$d->id.'" '.$sel.'>'.$d->course_name.'</option>';
			
		}
		
		echo $html;
		
	}
	
	public function getsubCategories(){
		
		$id = $this->input->post("id");
		$sub_ids = $this->input->post("sub_ids");
		
		$this->db->select("tbl_subject_category.category_name,tbl_subject_category.id");
		$this->db->join("tbl_subject_category","tbl_subcat_course_links.subject_category=tbl_subject_category.id");
		$data = $this->db->get_where("tbl_subcat_course_links",["tbl_subcat_course_links.course"=>$id])->result();
		
		foreach($data as $d){
			
			$sel = "";
			
			if(in_array($d->id,$sub_ids)){
				$sel = "selected";
			}
			
			echo '<option value="'.$d->id.'" cname="'.$d->category_name.'" '.$sel.'>'.$d->category_name.'</option>';
			
		}
		
//		echo json_encode($data);
		
	}
	
	public function getCreditweightage(){
		
		$weightage = $this->input->post("weightage");
		$cid = $this->input->post("cid");
			
		$cdata = $this->db->get_where("tbl_courses",["id"=>$cid])->row();
		$min_credits = $cdata->min_credits; 
		$max_credits = $cdata->max_credits;

		$max_weightage = round(($min_credits/100)*$weightage);
		$min_weightage = round(($max_credits/100)*$weightage);
		
		echo "<b>Credits:</b> ($max_weightage - $min_weightage)";
		
	}
	
	public function logout(){
		
		$this->session->sess_destroy();
		redirect("institute-login");
		
	}
	
}
