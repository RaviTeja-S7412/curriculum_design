<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	public function __construct(){
		
		parent::__construct();
		if(!$this->session->userdata('institute_id')){
        	redirect('/institute-login');
        }
		
	}

	public function index(){
		$this->load->view('dashboard');
	}
	
	public function create(){
		
		$bid = $this->input->get("bid");
		if($bid){
			$this->db->select("*");
			$this->db->join("tbl_institute_branches","tbl_institute_branches.id=tbl_institute_curriculum_design.branch_id");
			$this->db->join("tbl_courses","tbl_courses.id=tbl_institute_curriculum_design.course");
			$data["branch_data"] = $this->db->get_where("tbl_institute_curriculum_design",["branch_id"=>$this->input->get("bid")])->row();
			$data["sub_categories"] = json_decode($data["branch_data"]->subject_categories);	
		}
		
//		echo '<pre>';
//		print_r($data);
//		exit();
		
		$data["programs"] = $this->db->get_where("tbl_programs",["status"=>1,"deleted"=>0])->result();
		$this->load->view('create',$data);
		
	}
	
	public function view(){
		
		$data["cdata"] = $this->db->order_by("id","desc")->get_where("tbl_institute_branches",["status"=>1,"institute_id"=>$this->session->userdata("institute_id")])->result();
		$this->load->view('view',$data);
		
	}
	
	public function addSubjects(){
		
		$data["branch_data"] = json_decode($this->session->userdata("branch_data"));
		$data["sub_categories"] = $data["branch_data"]->sub_categories;
		
		$this->load->view('addSubjects',$data);
		
	}
	
	public function addCredits(){
		
		$this->db->select("*");
		$this->db->join("tbl_institute_branches","tbl_institute_branches.id=tbl_institute_curriculum_design.branch_id");
		$this->db->join("tbl_courses","tbl_courses.id=tbl_institute_curriculum_design.course");
		$data["branch_data"] = $this->db->get_where("tbl_institute_curriculum_design",["branch_id"=>$this->input->get("bid")])->row();
		$data["sub_categories"] = json_decode($data["branch_data"]->subject_categories);
		$data["semesters"] = $this->db->get_where("tbl_semesters",["status"=>1])->result();
		
		$weightage = json_decode($data["branch_data"]->weightage);
		
		$weigtages = [];
		foreach($weightage as $k => $w){
			
			$min_credits = $data["branch_data"]->min_credits; 
			$max_credits = $data["branch_data"]->max_credits;
			
			$wdata = [];
			$wdata["max_weightage"] = round(($min_credits/100)*$w);
			$wdata["min_weightage"] = round(($max_credits/100)*$w);
			$wdata["sub_category"] = $data["sub_categories"][$k];
			
			$weigtages[] = $wdata;
			
		}
		
		
		$totalCredits = 0;
		foreach(json_decode($data["branch_data"]->credits) as $tc){
			
			$totalCredits += array_sum($tc->total_credits);
			
		}
		
		$data["weigtages"] = $weigtages;
		$data["totalCredits"] = $totalCredits;
		$data["program"] = $this->db->get_where("tbl_programs",["id"=>$data["branch_data"]->program])->row();
		$data["course"] = $this->db->get_where("tbl_courses",["id"=>$data["branch_data"]->course])->row();
		
		$this->load->view('addCredits',$data);
		
	}
	
	public function insertCredits(){
		
		$bid = $this->input->post("bid");
		$bd = $this->db->get_where("tbl_institute_branches",["id"=>$bid])->row();
		$bdata = $this->db->get_where("tbl_institute_curriculum_design",["branch_id"=>$bid])->row();
		$cdata = $this->db->get_where("tbl_courses",["id"=>$bdata->course])->row();
		
		$subCats = json_decode($bdata->subject_categories);
		
		$credits = [];
		
		$totalCredits = 0;
		foreach($subCats as $sc){
			
			$lectures = $this->input->post("lecture_hours_per_week-$sc");
			$tutorial = $this->input->post("tutorial_hours_per_week-$sc");
			$lab = $this->input->post("lab_hours_per_week-$sc");
			$total = $this->input->post("total_credits-$sc");
			$semesters = $this->input->post("semester-$sc");
			
			$totalCredits += array_sum($total);
			$credits[] = ["lecture_hours_per_week"=>$lectures,"tutorial_hours_per_week"=>$tutorial,"lab_hours_per_week"=>$lab,"total_credits"=>$total,"semesters"=>$semesters];
			
		}
		
		if($totalCredits < $cdata->min_credits){
			
			echo json_encode(["status"=>false,"msg"=>"Total Credits Should Not be Less than Minimum Credits."]);
			exit();
			
		}
		
		
		$d = $this->db->where("branch_id",$bid)->update("tbl_institute_curriculum_design",["credits"=>json_encode($credits),"status"=>1]);
		
		if($d){
			
			$this->db->where("id",$bid)->update("tbl_institute_branches",["status"=>1]);
			echo json_encode(["status"=>true,"msg"=>"Credits Added Successfully, Curriculum Design Successfully Created For $bd->branch_name."]);
			
			$this->session->unset_userdata("branch_data");
			exit();
			
		}else{
			
			echo json_encode(["status"=>false,"msg"=>"Error Occured Please Try Again."]);
			exit();
		}
		
	}
	
	public function insertSubjects(){
		
		$inst_id = $this->session->userdata("institute_id");
		$branch_data = json_decode($this->session->userdata("branch_data"));
		$data = $this->input->post();
		
		$subjects = [];
		foreach($branch_data->sub_cats as $sc){
			
			$chkSubjects = $this->input->post("subjects-$sc");
			if(!$chkSubjects){
				echo json_encode(["status"=>false,"msg"=>"Please Select Subjects In All Subject Categories"]);
				exit();
			}
			$subjects[] = $chkSubjects;
			
		}

		$bdata = [
			"institute_id" => $inst_id,
			"branch_name" => $branch_data->branch_name
		];
		
		$d = $this->db->insert("tbl_institute_branches",$bdata);
		$lid = $this->db->insert_id();
		
		if($d){
			
			$pdata = [
				"branch_id" => $lid,
				"program" => $branch_data->program,
				"course" => $branch_data->course,
				"subject_categories" => json_encode($branch_data->sub_cats),
				"weightage" => json_encode($branch_data->weightage),
				"subjects" => json_encode($subjects),
			];
			
			$pd = $this->db->insert("tbl_institute_curriculum_design",$pdata);
			
			if($pd){
				echo json_encode(["status"=>true,"msg"=>"Subjects Added Successfully Please Add Credits to Subjects.","bid"=>$lid]);
				exit();
			}else{
				echo json_encode(["status"=>false,"msg"=>"Error Occured Please Try Again."]);
				exit();
			}
			
		}else{
			
			echo json_encode(["status"=>false,"msg"=>"Error Occured Please Try Again."]);
			exit();
			
		}
		
	}
	
	public function insertBranch(){
		
		$inst_id = $this->session->userdata("institute_id");
		$branch_name = $this->input->post("branch_name");
		$program = $this->input->post("program");
		$course = $this->input->post("course");
		$sub_categories = $this->input->post("sub_categories");
		$weightage = $this->input->post("weightage");
		$sub_cats = $this->input->post("sub_cats");
		
		if(array_sum($weightage) != 100){
			
			echo json_encode(["status"=>false,"msg"=>"weightage should be equal to 100%"]);
			exit();
			
		}
		
		$d = $this->session->set_userdata("branch_data",json_encode($_POST));
		
		if($this->session->userdata("branch_data")){
			
			echo json_encode(["status"=>true,"msg"=>"Branch Created Successfully Please Add Subjects."]);
			exit();
			
		}else{
			
			echo json_encode(["status"=>false,"msg"=>"Error Occured Please Try Again."]);
			exit();
			
		}
		
	}
	
	public function delBranch($id){
		
		$this->db->delete("tbl_institute_branches",["id"=>$id]);
		$this->db->delete("tbl_institute_curriculum_design",["branch_id"=>$id]);
		redirect("view-curriculum-designs");
		
	}
		
	public function logout(){
		
		$this->session->sess_destroy();
		redirect("institute-login");
		
	}
	
}
